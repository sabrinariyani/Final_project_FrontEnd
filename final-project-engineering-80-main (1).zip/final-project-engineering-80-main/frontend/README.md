# GedeBOOK

### Preview

[GedeBOOK](https://GedeBOOK.netlify.app/)

### Usage

```sh
$ npm install
```

```sh
$ npm start
# Visit http://localhost:3000
```
