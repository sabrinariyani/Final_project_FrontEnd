import React from 'react';

function Reports() {
  return (
    <div className='reports'>
      <h1>Daftar Buku</h1>
    </div>
  );
}

export default Reports;
