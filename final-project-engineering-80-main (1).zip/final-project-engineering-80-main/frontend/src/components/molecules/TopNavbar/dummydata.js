export const data = {
    notification: [
        { time: '7 menit yang lalu', title: 'Pengembalian', message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, quod?', image: 'https://cdn.waterstones.com/bookjackets/large/9780/2413/9780241361979.jpg' },
        { time: '8 menit yang lalu', title: 'Pengembalian', message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, quod?', image: 'https://cdn.waterstones.com/bookjackets/large/9780/2413/9780241361979.jpg' },
        { time: '19 menit yang lalu', title: 'Pengembalian', message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, quod?', image: 'https://cdn.waterstones.com/bookjackets/large/9780/2413/9780241361979.jpg' },
        { time: '24 menit yang lalu', title: 'Pengembalian', message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, quod?', image: 'https://cdn.waterstones.com/bookjackets/large/9780/2413/9780241361979.jpg' },
        { time: '32 menit yang lalu', title: 'Pengembalian', message: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, quod?', image: 'https://cdn.waterstones.com/bookjackets/large/9780/2413/9780241361979.jpg' }
    ]
}